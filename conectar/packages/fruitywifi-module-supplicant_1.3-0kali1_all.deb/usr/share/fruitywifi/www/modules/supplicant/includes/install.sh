#!/bin/bash

apt-get -y install wpasupplicant

echo "..DONE.."
exit
