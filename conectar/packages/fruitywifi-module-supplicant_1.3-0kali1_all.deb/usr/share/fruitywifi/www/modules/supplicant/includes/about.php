<b>wpa_supplicant</b> - Wi-Fi Protected Access client and IEEE 802.1X supplicant
<br><br>
wpa_supplicant is copyright (c) 2003-2014, Jouni Malinen (j@w1.fi) and contributors.
